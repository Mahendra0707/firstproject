<?php
$dbname='mahasiswa';
$host='localhost';
$password='';
$username='root';
//Koneksi Ke MySQL
$cnn = mysqli_connect($host,$username,$password,$dbname);  
//Membuat Koneksi 
if(!$cnn){ 
	die("Koneksi Failed : ".mysqli_connect_error()); } 
//Membuat Tabel
	$sql ="CREATE TABLE username (
	id int(11) NOT NULL auto_increment,
	username VARCHAR(255) NOT NULL,
	password varchar(225) not null,
	
	
	CONSTRAINT pk_biodata PRIMARY KEY (id)
)";

if (mysqli_query($cnn, $sql)){ 
	echo "Table Berhasil di Buat"; 
} else { 
	echo "Table Gagal di Buat :".mysqli_error($cnn); } 
	mysqli_close($cnn); 
	?>

