<?php


//memulai session
session_start();

if ( isset($_SESSION['login'])) {
	header ('location: index.php') ;

	exit ;
}


require 'functions.php';


if (isset($_POST['login'])) {
	$login = login($_POST);
}
?>




<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>login</title>
	<link rel="stylesheet" type="text/css" href="">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" />
    <link rel="stylesheet" href="bootstrap/js/bootstrap.min.js" />
    <link rel="stylesheet" type="text/css" href="fontawesome/css/all.css">
</head>
<body>
	<div class="container">
		<div class="jumbotron text-center">
		<h3 >login user</h3>
	</div>

		<?php
		if (isset($login['error'])) :?>
			<p><?= $login['pesan'];   ?></p>
		<?php endif ; ?>

		
			

				
				<form action="" method="post">
					<div class="form-group row" align="center">        
						<div class="col-xs-3">

							<label>USERNAME</label>
							<input type="text" name="username" class="form-control"  autofocus="" autocomplete="off" placeholder="username..." /> 
						</div>
					</div>
					<div class="form-group row">   
						<div class="col-xs-3">

							<label>PASSWORD</label>
							<input type="password" name="password" class="form-control"  autocomplete="off" placeholder="password..." /> 
						</div>
					</div>
					<div class="form-group row">   
						<button type="submit" name="login" class="btn btn-success btn-sm">login</button>
						&nbsp;
						<a href="registrasi.php" class="btn btn-primary btn-sm">registrasi</a>
					</div>
				</form>
			
		</div>
	
</body>
</html>