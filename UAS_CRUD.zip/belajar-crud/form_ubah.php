<?php


//memulai session
session_start();

if ( !isset($_SESSION['login'])) {
  header ('location: form_login.php') ;

  exit ;
}


require'functions.php';


//ambil id
$id = $_GET["id"];

//query mahasiswa berdasarkan id
$mhs = query("SELECT * FROM data_calon_mahasiswa WHERE id = $id");

//mengecek tombol ubah sdh di klik

if (isset($_POST['ubah'])) {
  if (ubah($_POST) > 0) {

   echo
   "
   <script type='text/javascript'>
   alert('Data telah diubah');
   window.location='index.php';
   </script>
   ";
 }
    else //jika gagal
    {
      echo
      "
      <script type='text/javascript'>
      alert('Gagal diubah');
      window.location='index.php';
      </script>
      ";
    }

  }
  ?>
  <!DOCTYPE html>
  <html>
  <head>
    <title>ubah data siswa</title>
    <link rel="stylesheet" type="text/css" href="">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" />
    <link rel="stylesheet" href="bootstrap/js/bootstrap.min.js" />
    <link rel="stylesheet" type="text/css" href="fontawesome/css/all.css">
  </head>
  <body>
    <div class="container" >
      <div class="jumbotron text-center">
      <h1 align="center">UBAH DATA CALON MAHASISWA</h1>
    </div>

      <form action="" method="post" enctype="multipart/form-data">
        <input type="hidden" name="id" value="<?= $mhs["id"];?>"> 

        <label>FOTO : </label>
        <input type="hidden" name="gambar_lama" value="<?= $mhs["foto"];?>">
        <input type="file" name="foto" class="foto" onchange="previewImage()">
        <br>
        <img src="img/<?= $mhs["foto"];?>" width="100" style="display: block;" class="img-preview" >


      <br>

        
          <div class="col-xs-3">

            <label>NAMA</label>
            <input type="text" name="nama" class="form-control" required value="<?= $mhs["nama"];?>"  autocomplete="off" placeholder="nama..." /> 
          </div>

          

          <div class="col-xs-3">
            <label >JENIS KELAMIN </label>
            <input type="text" name="jenis_kelamin"class="form-control" required value="<?= $mhs["jenis_kelamin"];?>"  autocomplete="off" placeholder="jenis kelamin..." />
          </div>

          

          <div class="col-xs-3">
            <label >AGAMA</label>
            <input type="text" name="agama" class="form-control"required value="<?= $mhs["agama"];?>"  autocomplete="off" placeholder="agama..." />
          </div>
        
        
          <div class="col-xs-3">
            <label >TTL</label>
            <input type="date" name="ttl" class="form-control" required value="<?= $mhs["ttl"];?>"  autocomplete="off" placeholder="ttl..." />
          </div>

          

          <div class="col-xs-3">
            <label >JURUSAN</label>
            <input type="text" name="jurusan" class="form-control" required value="<?= $mhs["jurusan"];?>"  autocomplete="off" placeholder="jurusan..." />
          </div>

          

          <div class="col-xs-3">
            <label >ALAMAT</label>
            <input type="text" name="alamat" class="form-control" required value="<?= $mhs["alamat"];?>"  autocomplete="off" placeholder="alamat..." />
          </div>

          

          <div class="col-xs-3">
            <label >ASAL SEKOLAH</label>
            <input type="text" name="asal_sekolah" class="form-control" required value="<?= $mhs["asal_sekolah"];?>" autocomplete="off" placeholder="asal sekolah..." />
          </div>
        </div>
      <div align="center">
        <hr width="50%" align="center" color= "#7386D5 ">
        <button type="submit" name="ubah" class="btn btn-success btn-sm">ubah data</button>
        <a href='detail.php?id=<?= $mhs['id'];?>'class="btn btn-danger btn-sm">batal</a>
        <hr width="50%" align="center" color= "#7386D5 ">
    </div>
      </form>
</div>  
<br>
<br>

  </body>
  </html>
