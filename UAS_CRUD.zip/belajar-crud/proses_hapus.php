<?php
require 'functions.php';



$id = $_GET['id'];

if (hapus($id) > 0) {

		echo
		"
		<script type='text/javascript'>
		alert('Data telah dihapus');
		window.location='index.php';
		</script>
		";
	}
    else //jika gagal
    {
    	echo
    	"
    	<script type='text/javascript'>
    	alert('Gagal dihapus');
    	window.location='index.php';
    	</script>
    	";
    }



?>