<?php

//memulai session
session_start();

if ( !isset($_SESSION['login'])) {
    header ('location: form_login.php') ;

    exit ;
}




require 'functions.php';
$mhs=query("SELECT * FROM data_calon_mahasiswa ORDER BY nama ASC");




// tombol cari di klik
if (isset($_POST['cari'])){
    $mhs = cari($_POST['keyword']);



}
?>



<!DOCTYPE html>
<head>
    <meta charset="utf-8">
    
    <title>data calon mahasiswa</title>

    <link rel="stylesheet" type="text/css" href="style.css">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" />
    <link rel="stylesheet"  href="fontawesome/css/all.css">

</head>

<body>

    <div class="wrapper">
        <!-- Sidebar  -->
        <nav id="sidebar">
            <div id="dismiss">
                <i class="fas fa-window-close"></i>
            </div>

            <div class="sidebar-header">
                <h3>Sidebar menu</h3>
            </div>

            <ul class="list-unstyled components" >

                <li >
                    <a href="#homeSubmenu" data-toggle="collapse" aria-expanded="false"><i class="fas fa-home"> Home</i> </a>
                    
                </li>
            </li>
            <li >
                <a href="#"><i class="fas fa-info"> About</i></a>
                <a href="#pageSubmenu" data-toggle="collapse" aria-expanded="false" 
                \><i class="fas fa-clipboard"> Pages</i></a>
                <ul class="collapse list-unstyled" id="pageSubmenu">
                    <li >
                        <a href="#">Page 1</a>
                    </li>
                    <li >
                        <a href="#">Page 2</a>
                    </li>
                    <li >
                        <a href="#">Page 3</a>
                    </li>
                </ul>
            </li>
            <li >
                <a href="#"><i class="fas fa-address-book"> Portfolio</i></a>
            </li >
            <li >
                <a href="#"><i class="fas fa-phone-alt"> Contact</i></a>
            </li>
            <li >
                <a  href="logout.php"><i class="fas fa-sign-out-alt"> logout</i></a>
            </li>
        </ul>


    </nav>

    <!-- Page Content  -->
    <div id="content">

        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid">

                <button type="button" id="sidebarCollapse" class="btn btn-info">
                    <i class="fas fa-align-justify"></i>
                </button>
                <button class="btn btn-dark d-inline-block d-lg-none ml-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fas fa-align-justify"></i>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="nav navbar-nav ml-auto">
                        <li class="nav-item active">
                            <a class="nav-link" href="#">menu 1</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">menu 2</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">menu 3</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">menu 4</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>

        <div align="center">
            <h3>DATA CALON MAHASISWA</h3>
        </div>
        <div id="objek">

            <?php
            date_default_timezone_set('Asia/Jakarta');
            echo  date('d M Y (H:i)');
            ?>
            
       </div>
       <br>
       <div class="container">
           
           
            <a href="tambah_data.php" class="btn btn-primary"><i class="fas fa-plus">&nbsp; tambah data</i></a>

               <form action="" method="post"  id="cari" >
                   <input type="search"  name="keyword"  autocomplete="off" placeholder="cari data.....">
                   <button type="submit" name="cari" class="btn btn-warning btn-sm"><i class="fas fa-search"></i></button>
               </form>
           
           <br>
           <br>

           <table id="example" class="table table-striped table-bordered table-hovered" border="1" cellspacing="0">
            <tr >
                <th>NO.</th>
                <th >NAMA SISWA</th>
                <th >JURUSAN DIAMBIL</th>
                <th >ALAMAT</th>
                <th >ASAL SEKOLAH</th>
                <th >AKSI</th>
            </tr>

            <?php if (empty($mhs)) : ?>

                <tr align="center">
                    <td colspan="6" >

                        <p style="color: red" >data yang anda cari tidak ditemukan</p>
                    </td>
                </tr>
            <?php endif ; ?>
            <?php
            $i=1;
            ?>
            <?php
            foreach ($mhs as $row ):
                ?>
                <tr>
                    <td ><?= $i ?></td>
                    <td><?= $row['nama'];?></td>
                    <td><?= $row['jurusan'];?></td>
                    <td><?= $row['alamat'];?></td>
                    <td><?= $row['asal_sekolah'];?></td>
                    <td>

                        <a href='detail.php?id=<?= $row['id'] ;?>'> <button class="btn btn-success btn-sm"><i class="fas fa-user"></i> detail</button></a>

                    </td>
                </tr>
                <?php
                $i++;
                ?>
                <?php
            endforeach;
            ?>

        </table>
    </div>
</div>

<div class="overlay"></div>

<!-- jQuery CDN - Slim version (=without AJAX) -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<!-- Popper.JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous"></script>
<!-- Bootstrap JS -->
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script>
<!-- jQuery Custom Scroller CDN -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/malihu-custom-scrollbar-plugin/3.1.5/jquery.mCustomScrollbar.concat.min.js"></script>

<script type="text/javascript">
    $(document).ready(function () {
        $("#sidebar").mCustomScrollbar({
            theme: "minimal"
        });

        $('#dismiss, .overlay').on('click', function () {
            $('#sidebar').removeClass('active');
            $('.overlay').removeClass('active');
        });

        $('#sidebarCollapse').on('click', function () {
            $('#sidebar').addClass('active');
            $('.overlay').addClass('active');
            $('.collapse.in').toggleClass('in');
            $('a[aria-expanded=true]').attr('aria-expanded', 'false');
        });
    });
</script>
</body>

</html>