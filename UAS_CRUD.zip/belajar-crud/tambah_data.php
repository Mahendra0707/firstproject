<?php


//memulai session
session_start();

if ( !isset($_SESSION['login'])) {
	header ('location: form_login.php') ;

	exit ;
}


require'functions.php';



//mengecek tombol tambah sdh di klik

if (isset($_POST['tambah'])) {
	if (tambah($_POST) > 0) {

		echo
		"
		<script type='text/javascript'>
		alert('Data telah ditambah');
		window.location='index.php';
		</script>
		";
	}
    else //jika gagal
    {
    	echo
    	"
    	<script type='text/javascript'>
    	alert('Gagal ditambah');
    	</script>
    	";
    }

}
?>
<!DOCTYPE html>
<html>
<head>
	<title>tambah data</title>
	<link rel="stylesheet" type="text/css" href="">
	<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" />
	<link rel="stylesheet" href="bootstrap/js/bootstrap.min.js" />
	<link rel="stylesheet" type="text/css" href="fontawesome/css/all.css">

</head>
<body>

	<div class="jumbotron text-center">
      <h1 align="center">TAMBAH DATA CALON MAHASISWA</h1>
    </div>
	<div class="container" style="background: #fafafa">
		
		<form action="" method="post" enctype="multipart/form-data" >		
			<div class="form-group row">
				<div class="col-xs-3">
					<label >NAMA</label>
					<input class="form-control"  type="text" name="nama" required="" autocomplete="off" placeholder="nama..." /><br>
					<P>JENIS KELAMIN</P>
				
					<label class="radio-inline">
						<input type="radio" name="jenis_kelamin" value="Laki-laki">Laki-laki
					</label>
					&nbsp;
					<label class="radio-inline">
						<input type="radio" name="jenis_kelamin" value="Perempuan">Perempuan
					</label>
				
				</div>

				&nbsp;

				<div class="col-xs-3">
					<label >TTL</label>
					<input class="form-control" type="date" name="ttl" required="" autocomplete="off" ><br>
					<p>AGAMA</p>
					<form id="form_combobox" name="agama">

						<select name="agama">
							<option value="HINDU">HINDU</option>
							<option value="ISLAM">ISLAM</option>
							<option value="KRISTEN">KRISTEN</option>
							<option value="KATOLIK">KATOLIK</option>
							<option value="BUDDHA">BUDDHA</option>
							<option value="KONG HU CU">KONG HU CU</option>
						</select>
				</div>

				&nbsp;                      

				<div class="col-xs-3">
						<label >ASAL SEKOLAH</label>
						<input class="form-control"  type="text" width="100px" name="asal_sekolah"  required="" autocomplete="off" placeholder="asal sekolah..." /><br>
						<P>JURUSAN</P>
						
						<label class="radio-inline">
							<input type="radio" name="jurusan" value="sistem komputer">sistem komputer
						</label>
						&nbsp;
						<label class="radio-inline">
							<input type="radio" name="jurusan" value="Manajemen Teknik Informatika (TI-MTI)">TI-MTI
						</label>
						&nbsp;
						<label class="radio-inline">
							<input type="radio" name="jurusan" value="Desain Grafis dan Multimedia (TI-DGM)">TI-DGM
						</label>
						&nbsp;
						<label class="radio-inline">
							<input type="radio" name="jurusan" value="Teknik Komputer Akuntansi dan Bisnis (TI-KAB)">TI-KAB
						</label>
						</div>
						<div class="col-lg-3">
						<label for="comment">ALAMAT</label>
						<textarea  class="form-control"  name="alamat"  required="" autocomplete="off" placeholder="alamat..." /></textarea>

					</div>
			</div>
			
				<div align="center">
				FOTO : <br>
				<input type="file" name="foto" class="foto" onchange="previewImage()">
				
				<img src="img/nophoto.png" width="100" style="display: block;" class="img-preview" >
				<br>
				<br>

				<hr width="100%" align="center" color= "#7386D5 ">
				<button type="submit" name="tambah" class="btn btn-success btn-sm">TAMBAH</button>
				<input type="reset" name="reset" class="btn btn-warning btn-sm">
				<a href="index.php" class="btn btn-danger btn-sm">BATAL</a>
				<hr width="100%" align="center" color= "#7386D5 ">
				</div>
			</form>
		</div>
		<!-- menghubungkan ke file javascipt,js  -->
		<script src="js/javascript.js"></script>
	</body>
	</html>