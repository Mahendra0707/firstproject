<?php
require 'functions.php';

//ambil data dari

$id = $_GET["id"];

//query mahasiswa berdasarkan id
$mhs = query("SELECT * FROM data_calon_mahasiswa WHERE id = $id");
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>detail data </title>
	 <link rel="stylesheet" type="text/css" href="">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" />
    <link rel="stylesheet" href="bootstrap/js/bootstrap.min.js" />
    <link rel="stylesheet" type="text/css" href="fontawesome/css/all.css">
</head>
<body>
	<div class="container">

		<h3 align="center">DETAIL CALON MAHASISWA</h3>
		<br>
		<div  class="tabel_daftar">

			<table class="table table-striped table bordered" align="center">

				<p align="center"><img  src="img/<?= $mhs["foto"];?>" width="100px" ></p>
				<hr width="50%" align="center" color= "#7386D5 ">
				<p><i class="fas fa-user"></i>&nbsp;:&nbsp;<?= $mhs["nama"];?></p>
				<p><i class="fas fa-venus-mars"></i>&nbsp;:&nbsp;<?= $mhs["jenis_kelamin"];?></p>
				<p><i class="fas fa-praying-hands"></i>&nbsp;:&nbsp;<?= $mhs["agama"];?></p>
				<p><i class="fas fa-calendar-alt"></i>&nbsp;:&nbsp;<?= $mhs["ttl"];?></p>
				<p><i class="fas fa-user-graduate"></i>&nbsp;:&nbsp;<?= $mhs["jurusan"];?></p>
				<p><i class="fas fa-map-marker-alt"></i>&nbsp;:&nbsp;<?= $mhs["alamat"];?></p>
				<p><i class="fas fa-school"></i>&nbsp;:&nbsp;<?= $mhs["asal_sekolah"];?></p>
				<hr width="100%" align="center" color= "#7386D5 ">
				<p align="center">
					<a href="index.php"><button class="btn btn-primary btn-sm"><i class="fas fa-outdent"> kembali</i></button></a> 
					<a href='form_ubah.php?id=<?= $mhs['id'];?>' onclick="return confirm ('apakah yakin?');"><button class="btn btn-success btn-sm"><i class="fas fa-edit"> ubah</i></button></a> 
					<a href='proses_hapus.php?id=<?= $mhs['id'];?>' onclick="return confirm ('apakah yakin?');"><button class="btn btn-danger btn-sm"><i class="fas fa-trash-alt"> hapus</i></button></a>
				</p>
				<hr width="100%" align="center" color= "#7386D5 ">



			</table>
		</div>
		<div class="overlay"></div>
	</body>
	</html>