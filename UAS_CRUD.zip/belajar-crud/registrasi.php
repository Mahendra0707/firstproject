<?php


//memulai session


require'functions.php';



//mengecek tombol tambah sdh di klik

if (isset($_POST['registrasi'])) {
	if(registrasi($_POST) > 0){
		echo
		"
		<script type='text/javascript'>
		alert('user baru sudah terdaftar');
		window.location='form_login.php';
		</script>
		";
	}
    else //jika gagal
    {
    	echo
    	"
    	<script type='text/javascript'>
    	alert('Gagal ditambah');
    	window.location='form_login.php';
    	</script>
    	";
    }

}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>regristasi user</title>
	<link rel="stylesheet" type="text/css" href="">
	<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" />
	<link rel="stylesheet" href="bootstrap/js/bootstrap.min.js" />
	<link rel="stylesheet" type="text/css" href="fontawesome/css/all.css">
</head>
<body>
	<div class="container">
		<div class="jumbotron text-center">
			<h3>registrasi</h3>
		</div>

		
			<form action="" method="post" enctype="multipart/form-data">
				<table border="1" align="center"> 
					<div class="form-group row">        
						<div class="col-xs-3">

							<label>USERNAME</label>
							<input type="text" name="username" class="form-control"  autofocus="" autocomplete="off" placeholder="username..." /> 
						</div>
					</div>
					<div class="form-group row">   
						<div class="col-xs-3">

							<label>PASSWORD</label>
							<input type="password" name="password1" class="form-control"  autocomplete="off" placeholder="password..." /> 
						</div>
					</div>
					
					<div class="form-group row">   
						<div class="col-xs-3">

							<label>ULANGI PASSWORD</label>
							<input type="password" name="password2" class="form-control"  autocomplete="off" placeholder="password..." /> 
						</div>
					</div>
					<div class="form-group row">   
						<button type="submit" name="registrasi" class="btn btn-success btn-sm">tambah user</button>
						&nbsp;
						<a href="form_login.php" class="btn btn-danger btn-sm">batal</a>
					</div>
				</form>
			</div>
		
	</div>

</body>
</html>
