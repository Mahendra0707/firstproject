<?php
//menghubungkan database
function koneksi ()
{
	return mysqli_connect( 'localhost','root','','mahasiswa');
}

function query($query)
{
	$conn = koneksi();
	$result = mysqli_query($conn,$query);

	//jika hasil data satu
	if (mysqli_num_rows($result) == 1) {
		return mysqli_fetch_assoc($result);
	}
	$rows = [];
	while ($row = mysqli_fetch_assoc($result)) {
		$rows[] = $row ;
	}

	return $rows;
}



function tambah($data)
{
    $conn = koneksi();


    $nama   = htmlspecialchars($data['nama']);
    $jenis_kelamin   = htmlspecialchars($data['jenis_kelamin']);
    $agama   = htmlspecialchars($data['agama']);
    $ttl   = htmlspecialchars($data['ttl']);
    $jurusan = htmlspecialchars($data['jurusan']);
    $alamat = htmlspecialchars($data['alamat']);
    $asal_sekolah   = htmlspecialchars($data['asal_sekolah']);
    //$foto   = htmlspecialchars($data['foto']);


    //uploud foto

    $foto = uploud();
    if (!$foto) {
        return false ;
    }

    $query =  "INSERT INTO data_calon_mahasiswa VALUES('', '$nama','$jenis_kelamin','$agama','$ttl','$jurusan', '$alamat', '$asal_sekolah','$foto' )";

    mysqli_query($conn,$query);

    return mysqli_affected_rows($conn);

}


function uploud()
{

    $nama_file = $_FILES['foto']['name'];
    $tipe_file =  $_FILES['foto']['type'];
    $ukuran_file =  $_FILES['foto']['size'];
    $error =  $_FILES['foto']['error'];
    $tmp_file =  $_FILES['foto']['tmp_name'];


        //ketika foto tidak diisi/dipilih

    if ($error == 4) {
       // echo
        //"
        //<script type='text/javascript'>
        //alert('foto belum ditambahkan');
        //</script>
        //";
        return 'nophoto.png' ;
    }



        //cek ekstensi file

    $daftar_foto = ['jpg','jpeg','png'];
    $ekstensi_file = explode('.', $nama_file);
    $ekstensi_file = strtolower(end($ekstensi_file));
    if (!in_array($ekstensi_file,$daftar_foto)) {
        echo 
        "<script type='text/javascript'>
        alert('file bukan termasuk gambar');
        </script>
        ";
        return false ;
    }


        //cek tipe file

    if ($tipe_file != 'image/jpeg' && $tipe_file != 'image/png') {

       echo 
       "<script type='text/javascript'>
       alert('file bukan termasuk gambar');
       </script>
       ";
       return false ;
   }


        //cek ukuran file

        //maxx 5mb
   if ($ukuran_file > 5000000) {
    echo 
    "<script type='text/javascript'>
    alert('ukuran file terlalu besar');
    </script>
    ";
    return false ;
}

        //membuat nama file baru

$nama_file_baru = uniqid();
$nama_file_baru .= '.' ;
$nama_file_baru .= $ekstensi_file;
        //penyimpanan file gambar

move_uploaded_file($tmp_file, 'img/' . $nama_file_baru);

return $nama_file_baru ;

}



function cari($keyword)
{
    $conn = koneksi();
    $query = "SELECT * FROM data_calon_mahasiswa where  nama like '%".$keyword."%' OR jenis_kelamin like '%".$keyword."%' OR agama like '%".$keyword."%' 
    OR ttl like '%".$keyword."%' OR jurusan like '%".$keyword."%' OR alamat like '%".$keyword."%' OR asal_sekolah like '%".$keyword."%'"; 

    $result = mysqli_query($conn,$query);

    $rows = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $rows[] = $row ;
    }

    return $rows;



}






function ubah($data)
{
    $conn = koneksi();

    $id  = htmlspecialchars($data['id']);
    $nama   = htmlspecialchars($data['nama']);
    $jenis_kelamin   = htmlspecialchars($data['jenis_kelamin']);
    $agama   = htmlspecialchars($data['agama']);
    $ttl   = htmlspecialchars($data['ttl']);
    $jurusan = htmlspecialchars($data['jurusan']);
    $alamat = htmlspecialchars($data['alamat']);
    $asal_sekolah   = htmlspecialchars($data['asal_sekolah']);
    $gambar_lama = htmlspecialchars($data['gambar_lama']);



    $foto = uploud();
    if(!$foto){
        return false ;
    }

    if($foto == 'nophoto.png'){
        $foto = $gambar_lama;
    }

    $query = "UPDATE data_calon_mahasiswa SET nama = '$nama',jenis_kelamin='$jenis_kelamin',agama='$agama',ttl='$ttl',jurusan='$jurusan', alamat='$alamat', asal_sekolah='$asal_sekolah',foto ='$foto' WHERE id='$id'";

    mysqli_query($conn,$query);

    return mysqli_affected_rows($conn);

}




function hapus($id)
{

    $conn = koneksi();
    
    //hapus file gambar
    $mhs = query("SELECT * FROM data_calon_mahasiswa WHERE id = $id");
    if ($mhs['foto'] != 'nophoto.png'){
        unlink('img/' . $mhs['foto']);
    }


    mysqli_query($conn, "DELETE FROM data_calon_mahasiswa WHERE id = $id") or die(mysqli_error($conn));

    return mysqli_affected_rows($conn);

}




function login($data)
{


    $conn = koneksi();

    $username  = $data['username'];
    $password   = $data['password'];

        //cek username
    if ( $username = query("SELECT * FROM username WHERE username = '$username'")) {

        //cek password
        if (password_verify($password,$username['password'])){
         //set session
            $_SESSION['login'] = true ;       

            header('location: index.php') ;
            

            exit ;   
        }


        
    }
    return[
        'error' => true ,
        'pesan' => 'username/password salah'
    ];

}


function registrasi($data)

{


    $conn = koneksi();

    $username   = htmlspecialchars(strtolower($data['username']) );
    $password1 = mysqli_real_escape_string($conn, $data['password1']);
    $password2 = mysqli_real_escape_string($conn, $data['password2']);

    if(empty($username) || empty($password1) || empty($password2)) {

        echo "<script>
        alert('username / password kosong') ;
        window.location='registrasi.php';
        </script>
        ";
        return false ;
    }

    if ( query("SELECT * FROM username WHERE username = '$username'")) {

       echo "<script>
       alert('username / sudah terdaftar') ;
       window.location='form_login.php';
       </script>
       ";
       return false ;
   }

             //jika passwprd tidak sama/sesuai
   if ($password1 !== $password2) {
       echo "<script>
       alert('password tidak sesuai') ;
       window.location='registrasi.php';
       </script>
       ";
       return false ;
   }
            //jika password kurang dari 8
   if(strlen($password1) < 8){
    echo "<script>
    alert('password harus lebih dari delapan baik huruf maupun angka') ;
    window.location='registrasi.php';
    </script>
    ";
    return false ;
}

            //jika username dan password sudah sesuai
            //enkripsi password 

$password_baru = password_hash($password1, PASSWORD_DEFAULT);

            //insert ke tabel user
$query = "INSERT INTO username
VALUES
(null,'$username','$password_baru')";

mysqli_query($conn , $query) or die(mysqli_error($conn));

return mysqli_affected_rows($conn);
}
?>






























